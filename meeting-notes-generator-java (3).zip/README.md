# Meeting Notes Generator (Java / Spring Boot port)

This is a Java/Spring Boot port of the original Python/Streamlit
`multilingual-meeting-notes-generator` project, restyled with a light
design system and extended with two features:

- **Speaker analysis**: each speaker gets a contribution-style tag
  (Decisive, Inquisitive, Supportive, Analytical, Persuasive, Reserved)
  derived from what they actually said, plus a speaking-time bar chart.
- **Action items**: tasks can be moved across a Not started / In
  progress / Done kanban board, and items with a due date can be
  exported as an `.ics` calendar file.

## Architecture

- **Spring Boot 3.3** (Java 17), Maven build
- **Thymeleaf** server-rendered UI + plain JS/fetch for interactivity
  (no Streamlit-style full reactive rerun; updates are explicit POST
  calls followed by a page reload)
- AssemblyAI and OpenAI are called via plain REST (`java.net.http.HttpClient`
  + Jackson) — no vendor SDK dependency
- In-memory session store (`MeetingSessionStore`) holds the current
  result and task statuses; this is single-process/single-user, matching
  the scope of the original demo (no database, no auth)

## Requirements

- Java 17+
- Maven 3.8+
- An [AssemblyAI](https://www.assemblyai.com/) API key
- An [OpenAI](https://platform.openai.com/) API key

## Setup

1. Unzip the project and `cd` into it.
2. Either:
   - Export your API keys as environment variables before running:
     ```bash
     export ASSEMBLYAI_API_KEY=your_key_here
     export OPENAI_API_KEY=your_key_here
     ```
   - Or leave them unset and paste your keys into the sidebar fields
     in the web UI each session.
3. Build and run:
   ```bash
   mvn spring-boot:run
   ```
4. Open **http://localhost:8080** in your browser.

## Project layout

```
src/main/java/com/meetingnotes/
  model/        Speaker, ActionItem, TranscriptSegment, MeetingResult
  service/      TranscriberService (AssemblyAI), TextAnalyzerService (OpenAI),
                MeetingProcessorService (orchestrator), ExportService (.ics/.md),
                MeetingSessionStore (in-memory session state)
  controller/   MeetingController (page + REST endpoints)
  config/       Thymeleaf helper beans (SummaryFormatter, ToneColors, etc.)
src/main/resources/
  templates/index.html   Single-page UI (sidebar + results)
  static/css/style.css   Design system / theme
  static/js/app.js       Upload, status updates, reset
  application.properties
```

## Known limitations

- This is a single-process demo app: state is held in memory and is
  lost on restart, and is shared across anyone hitting the same
  server (no per-user sessions, no auth) — same scope as the original
  Streamlit demo, not production-hardened.
- Due-date parsing for the calendar export only recognizes common,
  unambiguous formats (e.g. `2024-03-15`, `March 15, 2024`). Natural
  language like "next Friday" is intentionally skipped rather than
  guessed, so the exported calendar never contains a wrong date.
- This port was built and reviewed without a live `mvn compile` in
  the authoring environment (no network access to resolve Maven
  dependencies there). It has been manually checked for type
  correctness, Lombok builder usage, Thymeleaf expression syntax, and
  bean wiring, but please run `mvn compile` yourself and report back
  if you hit anything — happy to fix it.
