package com.meetingnotes.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.meetingnotes.model.Speaker;
import com.meetingnotes.model.TranscriptSegment;
import org.springframework.stereotype.Service;

import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Audio transcription via the AssemblyAI REST API, with speaker
 * diarization and automatic language detection.
 *
 * This mirrors src/services/transcriber.py from the original Python
 * project, but talks to AssemblyAI's HTTP API directly (upload -> create
 * transcript -> poll until complete) instead of using their SDK.
 */
@Service
public class TranscriberService {

    private static final String BASE_URL = "https://api.assemblyai.com/v2";
    private static final List<String> EXPECTED_LANGUAGES =
            List.of("en", "es", "fr", "de", "it", "pt", "hi", "zh", "ja", "ko");

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();
    private final ObjectMapper mapper = new ObjectMapper();

    /** Result of a transcription run: full text, segments, speakers, detected language. */
    public record TranscriptionResult(
            String fullText,
            List<TranscriptSegment> segments,
            List<Speaker> speakers,
            String language,
            int durationSeconds
    ) {}

    public TranscriptionResult transcribeAudio(File audioFile, String apiKey) throws Exception {
        String uploadUrl = uploadFile(audioFile, apiKey);
        String transcriptId = createTranscript(uploadUrl, apiKey);
        JsonNode transcript = pollUntilComplete(transcriptId, apiKey);

        JsonNode utterances = transcript.path("utterances");
        if (!utterances.isArray() || utterances.isEmpty()) {
            throw new IllegalStateException("No utterances found. Check audio quality and format.");
        }

        String fullText = transcript.path("text").asText("");
        if (fullText.trim().length() < 10) {
            throw new IllegalStateException("Insufficient text content. Check audio quality and language support.");
        }

        List<TranscriptSegment> segments = extractSegments(utterances);
        List<Speaker> speakers = extractSpeakers(utterances);
        String language = transcript.path("language_code").asText("en");
        int duration = transcript.path("audio_duration").asInt(0);

        return new TranscriptionResult(fullText, segments, speakers, language, duration);
    }

    private String uploadFile(File audioFile, String apiKey) throws Exception {
        byte[] bytes = Files.readAllBytes(audioFile.toPath());
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/upload"))
                .header("authorization", apiKey)
                .header("content-type", "application/octet-stream")
                .POST(HttpRequest.BodyPublishers.ofByteArray(bytes))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 300) {
            throw new IllegalStateException("AssemblyAI upload failed: " + response.body());
        }
        JsonNode json = mapper.readTree(response.body());
        return json.path("upload_url").asText();
    }

    private String createTranscript(String audioUrl, String apiKey) throws Exception {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("audio_url", audioUrl);
        body.put("speaker_labels", true);
        body.put("language_detection", true);
        body.put("punctuate", true);
        body.put("format_text", true);

        Map<String, Object> languageOptions = new LinkedHashMap<>();
        languageOptions.put("expected_languages", EXPECTED_LANGUAGES);
        languageOptions.put("fallback_language", "auto");
        body.put("language_detection_options", languageOptions);

        String json = mapper.writeValueAsString(body);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/transcript"))
                .header("authorization", apiKey)
                .header("content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 300) {
            throw new IllegalStateException("AssemblyAI transcript creation failed: " + response.body());
        }
        JsonNode result = mapper.readTree(response.body());
        return result.path("id").asText();
    }

    private JsonNode pollUntilComplete(String transcriptId, String apiKey) throws Exception {
        int maxWaitSeconds = 300;
        int waited = 0;

        while (waited < maxWaitSeconds) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/transcript/" + transcriptId))
                    .header("authorization", apiKey)
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            JsonNode json = mapper.readTree(response.body());
            String status = json.path("status").asText();

            if ("completed".equals(status)) {
                return json;
            }
            if ("error".equals(status)) {
                String errorMsg = json.path("error").asText("Unknown error");
                String detail = errorMsg.toLowerCase().contains("speaker")
                        ? "\n\nSpeaker diarization failed. Check audio quality and speaker separation."
                        : errorMsg.toLowerCase().contains("language")
                        ? "\n\nLanguage detection failed. Ensure clear speech in a supported language."
                        : "";
                throw new IllegalStateException("Transcription failed: " + errorMsg + detail);
            }

            Thread.sleep(2000);
            waited += 2;
        }
        throw new IllegalStateException("Transcription timeout");
    }

    private List<TranscriptSegment> extractSegments(JsonNode utterances) {
        List<TranscriptSegment> segments = new ArrayList<>();
        for (JsonNode u : utterances) {
            segments.add(TranscriptSegment.builder()
                    .startTime(u.path("start").asLong())
                    .endTime(u.path("end").asLong())
                    .speakerId(u.path("speaker").asText())
                    .text(u.path("text").asText())
                    .confidence(u.path("confidence").asDouble(0.8))
                    .build());
        }
        segments.sort((a, b) -> Long.compare(a.getStartTime(), b.getStartTime()));
        return segments;
    }

    private List<Speaker> extractSpeakers(JsonNode utterances) {
        Map<String, List<JsonNode>> bySpeaker = new LinkedHashMap<>();
        for (JsonNode u : utterances) {
            String speakerId = u.path("speaker").asText();
            bySpeaker.computeIfAbsent(speakerId, k -> new ArrayList<>()).add(u);
        }

        List<Speaker> speakers = new ArrayList<>();
        for (Map.Entry<String, List<JsonNode>> entry : bySpeaker.entrySet()) {
            int speakingTime = 0;
            int wordCount = 0;
            for (JsonNode u : entry.getValue()) {
                speakingTime += (u.path("end").asLong() - u.path("start").asLong()) / 1000;
                wordCount += u.path("text").asText("").trim().isEmpty()
                        ? 0
                        : u.path("text").asText().trim().split("\\s+").length;
            }
            speakers.add(Speaker.builder()
                    .id(entry.getKey())
                    .name(entry.getKey())
                    .speakingTime(speakingTime)
                    .wordCount(wordCount)
                    .build());
        }
        return speakers;
    }
}
