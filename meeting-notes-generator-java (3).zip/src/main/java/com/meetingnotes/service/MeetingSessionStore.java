package com.meetingnotes.service;

import com.meetingnotes.model.MeetingResult;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Simple in-memory store for the current meeting result and per-task
 * status overrides, replacing Streamlit's st.session_state.
 *
 * This is intentionally process-local and single-user, matching the
 * scope of the original demo app (no database, no auth). For a
 * multi-user deployment this would be swapped for a per-session or
 * per-user persisted store.
 */
@Service
public class MeetingSessionStore {

    private volatile MeetingResult currentResult;
    private final Map<String, String> taskStatus = new ConcurrentHashMap<>();

    public MeetingResult getCurrentResult() {
        return currentResult;
    }

    public void setCurrentResult(MeetingResult result) {
        this.currentResult = result;
        this.taskStatus.clear();
        if (result != null && result.getActionItems() != null) {
            result.getActionItems().forEach(item ->
                    taskStatus.put(item.getId(), item.getStatus() == null ? "Not started" : item.getStatus()));
        }
    }

    public Map<String, String> getTaskStatusMap() {
        return taskStatus;
    }

    public void updateTaskStatus(String taskId, String status) {
        taskStatus.put(taskId, status);
    }

    public void clear() {
        this.currentResult = null;
        this.taskStatus.clear();
    }
}
