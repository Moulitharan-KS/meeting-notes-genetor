package com.meetingnotes.service;

import com.meetingnotes.model.ActionItem;
import com.meetingnotes.model.MeetingResult;
import com.meetingnotes.model.Speaker;
import com.meetingnotes.model.TranscriptSegment;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Orchestrates the full meeting-processing pipeline: transcription,
 * speaker name + tone identification, summary, action items, and title.
 *
 * Mirrors src/services/audio_processor.py from the original project.
 * Each enrichment step is wrapped so a failure in one (e.g. tone
 * analysis) never aborts the overall result.
 */
@Service
public class MeetingProcessorService {

    private final TranscriberService transcriber;
    private final TextAnalyzerService analyzer;

    public MeetingProcessorService(TranscriberService transcriber, TextAnalyzerService analyzer) {
        this.transcriber = transcriber;
        this.analyzer = analyzer;
    }

    public MeetingResult processMeetingAudio(File audioFile, String assemblyAiKey, String openAiKey) throws Exception {
        TranscriberService.TranscriptionResult transcription;
        try {
            transcription = transcriber.transcribeAudio(audioFile, assemblyAiKey);
        } catch (Exception e) {
            throw new Exception("Audio transcription failed: " + e.getMessage(), e);
        }

        String fullTranscript = transcription.fullText();
        List<TranscriptSegment> segments = transcription.segments();
        List<Speaker> speakers = transcription.speakers();

        // Identify speaker names
        try {
            speakers = analyzer.identifySpeakerNames(fullTranscript, speakers, openAiKey);
        } catch (Exception e) {
            System.err.println("Warning: Speaker name identification failed: " + e.getMessage());
        }

        // Identify speaker tones (extended feature #1)
        try {
            speakers = analyzer.identifySpeakerTones(segments, speakers, openAiKey);
        } catch (Exception e) {
            System.err.println("Warning: Speaker tone analysis failed: " + e.getMessage());
        }

        // Summary
        String summary;
        try {
            summary = analyzer.generateMeetingSummary(fullTranscript, openAiKey);
            if (summary == null || summary.toLowerCase().contains("failed")) {
                summary = "Summary generation failed. Please review the transcript manually.";
            }
        } catch (Exception e) {
            summary = "Summary generation failed. Please review the transcript manually.";
        }

        // Action items
        List<ActionItem> actionItems;
        try {
            actionItems = analyzer.extractActionItems(fullTranscript, openAiKey);
        } catch (Exception e) {
            actionItems = List.of();
        }

        // Title
        String title;
        try {
            title = analyzer.generateMeetingTitle(fullTranscript, openAiKey);
            if (title == null || title.isBlank() || title.toLowerCase().contains("failed")) {
                title = "Meeting - " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy"));
            }
        } catch (Exception e) {
            title = "Meeting - " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy"));
        }

        int duration = transcription.durationSeconds();
        if (duration == 0 && !segments.isEmpty()) {
            duration = (int) (segments.stream().mapToLong(TranscriptSegment::getEndTime).max().orElse(0) / 1000);
        }

        return MeetingResult.builder()
                .title(title)
                .summary(summary)
                .speakers(speakers)
                .segments(segments)
                .actionItems(actionItems)
                .language(transcription.language())
                .duration(duration)
                .processedAt(LocalDateTime.now())
                .build();
    }
}
