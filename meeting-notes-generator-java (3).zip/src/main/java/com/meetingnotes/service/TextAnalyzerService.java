package com.meetingnotes.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.meetingnotes.model.ActionItem;
import com.meetingnotes.model.Speaker;
import com.meetingnotes.model.TranscriptSegment;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Text analysis via the OpenAI REST API (chat completions, gpt-4o).
 *
 * Mirrors src/services/text_analyzer.py: meeting summary, action item
 * extraction, speaker name identification, and meeting title generation.
 * Also adds identifySpeakerTones(), the backend half of the extended
 * "Speaker Analysis" feature.
 */
@Service
public class TextAnalyzerService {

    private static final String CHAT_URL = "https://api.openai.com/v1/chat/completions";
    private static final String MODEL = "gpt-4o";

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();
    private final ObjectMapper mapper = new ObjectMapper();

    // ------------------------------------------------------------------
    // Meeting summary
    // ------------------------------------------------------------------

    public String generateMeetingSummary(String transcriptText, String apiKey) {
        String truncated = truncate(transcriptText, 3000);

        String prompt = """
                Analyze this meeting transcript and provide a structured summary in English.

                IMPORTANT: Write the entire summary in English, regardless of the language of the original transcript.

                Provide your response in this EXACT JSON format:
                {
                    "topics_discussed": ["First main topic discussed", "Second main topic discussed", "Third main topic discussed"],
                    "key_decisions": ["First important decision made", "Second important decision made"],
                    "next_steps": ["First next step to take", "Second next step to take"]
                }

                Guidelines:
                - Keep each item concise but informative
                - Focus on the most important information
                - Do NOT include specific action items or task assignments
                - Do NOT mention "Juan will work on...", "Ana needs to...", etc.
                - Return ONLY the JSON object, no additional text

                Meeting Transcript:
                %s
                """.formatted(truncated);

        try {
            String responseText = callChatCompletion(
                    apiKey,
                    "You are a meeting summarizer. Return ONLY valid JSON in the exact format requested.",
                    prompt,
                    800,
                    0.1
            );
            JsonNode data = parseJsonLenient(responseText);
            if (data == null) {
                return "Summary generation failed. Please review the transcript manually.";
            }

            StringBuilder sb = new StringBuilder();
            sb.append("**Topics Discussed:**\n");
            for (JsonNode topic : data.path("topics_discussed")) {
                sb.append("• ").append(topic.asText()).append("\n");
            }
            sb.append("\n**Key Decisions:**\n");
            for (JsonNode decision : data.path("key_decisions")) {
                sb.append("• ").append(decision.asText()).append("\n");
            }
            sb.append("\n**Next Steps:**\n");
            for (JsonNode step : data.path("next_steps")) {
                sb.append("• ").append(step.asText()).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "Summary generation failed: " + e.getMessage();
        }
    }

    // ------------------------------------------------------------------
    // Action items
    // ------------------------------------------------------------------

    public List<ActionItem> extractActionItems(String transcriptText, String apiKey) {
        String truncated = truncate(transcriptText, 2000);

        String prompt = """
                Extract all action items, tasks, and commitments from this meeting transcript.

                CRITICAL LANGUAGE REQUIREMENT:
                - ALL action item descriptions MUST be written in English
                - This applies regardless of the original transcript language
                - Do NOT translate names of people, companies, or technical terms
                - ONLY translate the action descriptions to English

                Return the results as a JSON array with this exact format:
                [
                    {
                        "description": "Clear, specific description of what needs to be done",
                        "assignee": "Person responsible (if mentioned, otherwise null)",
                        "due_date": "Due date or timeline (if mentioned, otherwise null)",
                        "priority": "high/medium/low based on urgency and importance"
                    }
                ]

                Look for tasks assigned to people, follow-up actions, deadlines, and commitments.
                Be thorough and extract all actionable items, even if they seem minor.

                Meeting Transcript:
                %s
                """.formatted(truncated);

        List<ActionItem> items = new ArrayList<>();
        try {
            String responseText = callChatCompletion(apiKey, null, prompt, 500, 0.2);
            JsonNode arr = parseJsonLenientArray(responseText);
            if (arr == null) return items;

            int idx = 0;
            for (JsonNode node : arr) {
                items.add(ActionItem.builder()
                        .id("task-" + idx++)
                        .description(node.path("description").asText(""))
                        .assignee(textOrNull(node, "assignee"))
                        .dueDate(textOrNull(node, "due_date"))
                        .priority(node.path("priority").asText("medium"))
                        .status("Not started")
                        .build());
            }
        } catch (Exception e) {
            System.err.println("Action item extraction failed: " + e.getMessage());
        }
        return items;
    }

    // ------------------------------------------------------------------
    // Speaker name identification
    // ------------------------------------------------------------------

    public List<Speaker> identifySpeakerNames(String transcriptText, List<Speaker> speakers, String apiKey) {
        if (speakers == null || speakers.isEmpty()) return List.of();

        String truncated = truncate(transcriptText, 1500);
        String speakerIds = speakers.stream().map(Speaker::getId).toList().toString();

        String prompt = """
                You are an expert meeting analyst. Analyze this transcript to identify who each speaker is by their real names.

                The transcript shows speaker IDs like A, B, C, etc. Map these to actual names using:
                - The facilitator who opens/closes the meeting and calls on others by name
                - Direct name mentions when people are called upon
                - Self-referential statements

                If uncertain about a mapping, use "Speaker X" for that ID.

                Return ONLY a JSON object mapping speaker IDs to names.
                Use these speaker IDs: %s

                Example format: {"A": "Juan", "B": "Ana", "C": "Facilitator"}

                Meeting Transcript:
                %s
                """.formatted(speakerIds, truncated);

        try {
            String responseText = callChatCompletion(apiKey, null, prompt, 300, 0.1);
            JsonNode nameMap = parseJsonLenient(responseText);
            if (nameMap == null) return speakers;

            List<Speaker> updated = new ArrayList<>();
            for (Speaker speaker : speakers) {
                String name = nameMap.has(speaker.getId())
                        ? nameMap.get(speaker.getId()).asText()
                        : "Speaker " + speaker.getId();
                updated.add(Speaker.builder()
                        .id(speaker.getId())
                        .name(name)
                        .speakingTime(speaker.getSpeakingTime())
                        .wordCount(speaker.getWordCount())
                        .build());
            }
            return updated;
        } catch (Exception e) {
            System.err.println("Speaker name identification failed: " + e.getMessage());
            return speakers;
        }
    }

    // ------------------------------------------------------------------
    // Speaker tone analysis (extended feature #1 backend)
    // ------------------------------------------------------------------

    public List<Speaker> identifySpeakerTones(List<TranscriptSegment> segments, List<Speaker> speakers, String apiKey) {
        if (speakers == null || speakers.isEmpty()) return List.of();

        Map<String, StringBuilder> excerpts = new LinkedHashMap<>();
        for (Speaker speaker : speakers) {
            excerpts.put(speaker.getId(), new StringBuilder());
        }
        for (TranscriptSegment seg : segments) {
            StringBuilder sb = excerpts.get(seg.getSpeakerId());
            if (sb != null) {
                sb.append(seg.getText()).append(" ");
            }
        }

        StringBuilder excerptBlock = new StringBuilder();
        for (Map.Entry<String, StringBuilder> entry : excerpts.entrySet()) {
            String text = truncate(entry.getValue().toString(), 800);
            if (!text.isBlank()) {
                excerptBlock.append("Speaker ").append(entry.getKey()).append(": ").append(text).append("\n\n");
            }
        }

        if (excerptBlock.toString().isBlank()) {
            return speakers;
        }

        String prompt = """
                You are analyzing how each participant contributed to a meeting, based only on what they said below.

                For EACH speaker ID listed, choose ONE tone label from this fixed set that best
                characterizes their contribution style:
                ["Decisive", "Inquisitive", "Supportive", "Analytical", "Persuasive", "Reserved"]

                Also write a single short sentence (max 15 words) explaining why, in English.

                Return ONLY a JSON object in this exact format:
                {
                    "A": {"tone": "Decisive", "note": "Made clear calls on next steps and deadlines."},
                    "B": {"tone": "Inquisitive", "note": "Frequently asked clarifying questions about scope."}
                }

                Speaker statements:
                %s
                """.formatted(truncate(excerptBlock.toString(), 4000));

        try {
            String responseText = callChatCompletion(apiKey, null, prompt, 400, 0.2);
            JsonNode toneMap = parseJsonLenient(responseText);
            if (toneMap == null) return speakers;

            List<Speaker> updated = new ArrayList<>();
            for (Speaker speaker : speakers) {
                JsonNode info = toneMap.path(speaker.getId());
                updated.add(Speaker.builder()
                        .id(speaker.getId())
                        .name(speaker.getName())
                        .speakingTime(speaker.getSpeakingTime())
                        .wordCount(speaker.getWordCount())
                        .tone(info.has("tone") ? info.get("tone").asText() : null)
                        .toneNote(info.has("note") ? info.get("note").asText() : null)
                        .build());
            }
            return updated;
        } catch (Exception e) {
            System.err.println("Speaker tone analysis failed: " + e.getMessage());
            return speakers;
        }
    }

    // ------------------------------------------------------------------
    // Meeting title
    // ------------------------------------------------------------------

    public String generateMeetingTitle(String transcriptText, String apiKey) {
        String truncated = truncate(transcriptText, 1000);

        String prompt = """
                Generate a concise, descriptive title for this meeting based on its content.

                IMPORTANT:
                - Return ONLY the title, no additional text
                - Make it 3-8 words maximum
                - Use title case (Capitalize Important Words)
                - Examples: "Weekly Team Standup", "Project Planning Session", "Client Requirements Review"

                Meeting Transcript:
                %s
                """.formatted(truncated);

        try {
            String title = callChatCompletion(apiKey, null, prompt, 20, 0.3);
            return title.replaceAll("^[\"']|[\"']$", "").trim();
        } catch (Exception e) {
            System.err.println("Title generation failed: " + e.getMessage());
            return "Meeting - " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy"));
        }
    }

    // ------------------------------------------------------------------
    // Shared HTTP helper
    // ------------------------------------------------------------------

    private String callChatCompletion(String apiKey, String systemPrompt, String userPrompt,
                                       int maxTokens, double temperature) throws Exception {
        List<Map<String, String>> messages = new ArrayList<>();
        if (systemPrompt != null) {
            messages.add(Map.of("role", "system", "content", systemPrompt));
        }
        messages.add(Map.of("role", "user", "content", userPrompt));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", MODEL);
        body.put("messages", messages);
        body.put("max_tokens", maxTokens);
        body.put("temperature", temperature);

        String json = mapper.writeValueAsString(body);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(CHAT_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 300) {
            throw new IllegalStateException("OpenAI request failed (" + response.statusCode() + "): " + response.body());
        }

        JsonNode result = mapper.readTree(response.body());
        return result.path("choices").get(0).path("message").path("content").asText("").trim();
    }

    private String truncate(String text, int maxChars) {
        if (text == null) return "";
        return text.length() <= maxChars ? text : text.substring(0, maxChars);
    }

    private String textOrNull(JsonNode node, String field) {
        JsonNode value = node.path(field);
        if (value.isNull() || value.isMissingNode()) return null;
        String text = value.asText();
        return text.isBlank() ? null : text;
    }

    /** Strips markdown code fences and parses a JSON object, returning null on failure. */
    private JsonNode parseJsonLenient(String raw) {
        String cleaned = stripCodeFences(raw);
        try {
            return mapper.readTree(cleaned);
        } catch (Exception e) {
            Matcher m = Pattern.compile("\\{.*\\}", Pattern.DOTALL).matcher(cleaned);
            if (m.find()) {
                try {
                    return mapper.readTree(m.group());
                } catch (Exception ignored) {
                    return null;
                }
            }
            return null;
        }
    }

    /** Strips markdown code fences and parses a JSON array, returning null on failure. */
    private JsonNode parseJsonLenientArray(String raw) {
        String cleaned = stripCodeFences(raw);
        try {
            JsonNode node = mapper.readTree(cleaned);
            return node.isArray() ? node : null;
        } catch (Exception e) {
            Matcher m = Pattern.compile("\\[.*\\]", Pattern.DOTALL).matcher(cleaned);
            if (m.find()) {
                try {
                    return mapper.readTree(m.group());
                } catch (Exception ignored) {
                    return null;
                }
            }
            return null;
        }
    }

    private String stripCodeFences(String raw) {
        String text = raw.trim();
        if (text.startsWith("```json")) {
            text = text.replaceFirst("```json", "").trim();
        } else if (text.startsWith("```")) {
            text = text.replaceFirst("```", "").trim();
        }
        if (text.endsWith("```")) {
            text = text.substring(0, text.length() - 3).trim();
        }
        return text;
    }
}
