package com.meetingnotes.service;

import com.meetingnotes.model.ActionItem;
import com.meetingnotes.model.MeetingResult;
import com.meetingnotes.model.Speaker;
import com.meetingnotes.model.TranscriptSegment;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Builds the two downloadable artifacts: a Markdown export of the full
 * meeting notes, and an .ics calendar file for action items with a
 * due date (extended feature #2's calendar export).
 *
 * No external calendar library is used; .ics is a simple enough text
 * format to hand-build, matching the approach in the original Python
 * project's _build_ics().
 */
@Service
public class ExportService {

    private static final List<DateTimeFormatter> DUE_DATE_FORMATS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            new DateTimeFormatterBuilder().appendPattern("MMMM d, yyyy").toFormatter(Locale.ENGLISH),
            new DateTimeFormatterBuilder().appendPattern("MMMM d")
                    .parseDefaulting(java.time.temporal.ChronoField.YEAR, LocalDate.now().getYear())
                    .toFormatter(Locale.ENGLISH),
            new DateTimeFormatterBuilder().appendPattern("MMM d, yyyy").toFormatter(Locale.ENGLISH),
            new DateTimeFormatterBuilder().appendPattern("MMM d")
                    .parseDefaulting(java.time.temporal.ChronoField.YEAR, LocalDate.now().getYear())
                    .toFormatter(Locale.ENGLISH)
    );

    /**
     * Best-effort parse of a free-text due date. Only common, unambiguous
     * formats are attempted; anything else (e.g. "Friday", "next sprint")
     * is skipped rather than guessed incorrectly, so the exported
     * calendar never contains a wrong date.
     */
    public LocalDate parseDueDate(String dueDate) {
        if (dueDate == null || dueDate.isBlank()) return null;
        String trimmed = dueDate.trim();
        for (DateTimeFormatter fmt : DUE_DATE_FORMATS) {
            try {
                return LocalDate.parse(trimmed, fmt);
            } catch (DateTimeParseException ignored) {
                // try next format
            }
        }
        return null;
    }

    public String buildIcs(List<ActionItem> items) {
        StringBuilder sb = new StringBuilder();
        sb.append("BEGIN:VCALENDAR\n");
        sb.append("VERSION:2.0\n");
        sb.append("PRODID:-//Meeting Notes Generator//EN\n");

        for (ActionItem item : items) {
            LocalDate parsed = parseDueDate(item.getDueDate());
            if (parsed == null) continue;

            String dtStart = parsed.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            String dtEnd = parsed.plusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
            String summary = item.getDescription().replace("\n", " ").replace(",", "\\,");

            StringBuilder description = new StringBuilder();
            if (item.getAssignee() != null && !item.getAssignee().isBlank()) {
                description.append("Assigned to: ").append(item.getAssignee());
            }
            if (item.getPriority() != null && !item.getPriority().isBlank()) {
                if (description.length() > 0) description.append(" | ");
                description.append("Priority: ")
                        .append(item.getPriority().substring(0, 1).toUpperCase())
                        .append(item.getPriority().substring(1));
            }

            sb.append("BEGIN:VEVENT\n");
            sb.append("UID:").append(UUID.randomUUID()).append("\n");
            sb.append("DTSTAMP:").append(java.time.Instant.now()
                    .toString().replaceAll("[-:]", "").replace(".000Z", "Z")).append("\n");
            sb.append("DTSTART;VALUE=DATE:").append(dtStart).append("\n");
            sb.append("DTEND;VALUE=DATE:").append(dtEnd).append("\n");
            sb.append("SUMMARY:").append(summary).append("\n");
            sb.append("DESCRIPTION:").append(description.toString().replace(",", "\\,")).append("\n");
            sb.append("END:VEVENT\n");
        }

        sb.append("END:VCALENDAR\n");
        return sb.toString();
    }

    public String generateMarkdownExport(MeetingResult result, Map<String, String> taskStatusOverrides) {
        StringBuilder md = new StringBuilder();
        md.append("# ").append(result.getTitle()).append("\n\n");
        md.append("**Processed on:** ")
                .append(result.getProcessedAt().format(DateTimeFormatter.ofPattern("MMMM d, yyyy 'at' hh:mm a")))
                .append("\n");
        md.append("**Duration:** ").append(result.getDuration() / 60).append("m ")
                .append(result.getDuration() % 60).append("s\n\n");

        md.append("## Meeting Summary\n\n").append(result.getSummary()).append("\n\n");

        md.append("## Speakers\n\n");
        for (Speaker speaker : result.getSpeakers()) {
            md.append("### ").append(speaker.getName()).append("\n");
            md.append("- **Speaking Time:** ").append(speaker.getSpeakingTime() / 60).append("m ")
                    .append(speaker.getSpeakingTime() % 60).append("s\n");
            md.append("- **Words Spoken:** ").append(speaker.getWordCount()).append("\n");
            if (speaker.getTone() != null) {
                md.append("- **Contribution style:** ").append(speaker.getTone());
                if (speaker.getToneNote() != null) {
                    md.append(" \u2014 ").append(speaker.getToneNote());
                }
                md.append("\n");
            }
            md.append("\n");
        }

        md.append("## Action Items\n\n");
        int i = 1;
        for (ActionItem item : result.getActionItems()) {
            String status = taskStatusOverrides != null && taskStatusOverrides.containsKey(item.getId())
                    ? taskStatusOverrides.get(item.getId())
                    : item.getStatus();
            md.append("### Action ").append(i++).append("\n");
            md.append("**Description:** ").append(item.getDescription()).append("\n");
            md.append("**Status:** ").append(status).append("\n");
            if (item.getAssignee() != null) md.append("**Assigned to:** ").append(item.getAssignee()).append("\n");
            if (item.getDueDate() != null) md.append("**Due Date:** ").append(item.getDueDate()).append("\n");
            if (item.getPriority() != null) {
                md.append("**Priority:** ")
                        .append(item.getPriority().substring(0, 1).toUpperCase())
                        .append(item.getPriority().substring(1)).append("\n");
            }
            md.append("\n");
        }

        md.append("## Full Transcript\n\n");
        md.append("**Transcript Statistics:**\n");
        md.append("- Total Segments: ").append(result.getSegments().size()).append("\n");
        md.append("- Total Words: ").append(result.getTotalWords()).append("\n");
        md.append("- Average Confidence: ").append(String.format("%.2f", result.getAvgConfidence())).append("\n");
        md.append("- Unique Speakers: ").append(result.getUniqueSpeakersCount()).append("\n\n");

        md.append("### Complete Transcript\n\n");
        int segNum = 1;
        for (TranscriptSegment segment : result.getSegments()) {
            long startMinutes = segment.getStartTime() / 1000 / 60;
            long startSeconds = segment.getStartTime() / 1000 % 60;
            String timestamp = String.format("%02d:%02d", startMinutes, startSeconds);

            md.append("#### Segment ").append(segNum++).append(": Speaker ")
                    .append(segment.getSpeakerId()).append(" (").append(timestamp).append(")\n");
            md.append("*Confidence: ").append(String.format("%.2f", segment.getConfidence())).append("*\n\n");
            md.append(segment.getText()).append("\n\n");
            md.append("---\n\n");
        }

        return md.toString();
    }
}
