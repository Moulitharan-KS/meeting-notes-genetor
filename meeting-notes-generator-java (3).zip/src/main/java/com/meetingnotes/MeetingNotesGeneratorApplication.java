package com.meetingnotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeetingNotesGeneratorApplication {
    public static void main(String[] args) {
        SpringApplication.run(MeetingNotesGeneratorApplication.class, args);
    }
}
