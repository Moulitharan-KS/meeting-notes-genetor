package com.meetingnotes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/** Complete meeting analysis result, mirroring the original MeetingResult dataclass. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MeetingResult {
    private String title;
    private String summary;
    private List<Speaker> speakers;
    private List<TranscriptSegment> segments;
    private List<ActionItem> actionItems;
    private String language;
    private int duration; // seconds
    private LocalDateTime processedAt;

    public int getTotalWords() {
        if (segments == null) return 0;
        return segments.stream()
                .mapToInt(s -> {
                    String text = s.getText() == null ? "" : s.getText().trim();
                    return text.isEmpty() ? 0 : text.split("\\s+").length;
                })
                .sum();
    }

    public double getAvgConfidence() {
        if (segments == null || segments.isEmpty()) return 0.0;
        return segments.stream().mapToDouble(TranscriptSegment::getConfidence).average().orElse(0.0);
    }

    public long getUniqueSpeakersCount() {
        if (segments == null) return 0;
        return segments.stream().map(TranscriptSegment::getSpeakerId).distinct().count();
    }
}
