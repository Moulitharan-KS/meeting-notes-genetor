package com.meetingnotes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** A segment of transcribed speech (one utterance from one speaker). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TranscriptSegment {
    private long startTime; // milliseconds
    private long endTime;   // milliseconds
    private String speakerId;
    private String text;
    private double confidence;
}
