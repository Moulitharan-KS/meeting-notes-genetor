package com.meetingnotes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A task or action item extracted from the meeting.
 *
 * The status field powers the "Action Items" extended feature: each
 * task can be moved between Not started / In progress / Done on the
 * kanban-style board, and items with a parseable due date can be
 * exported to an .ics calendar file.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActionItem {
    private String id;
    private String description;
    private String assignee;
    private String dueDate;
    @Builder.Default
    private String priority = "medium";
    @Builder.Default
    private String status = "Not started";
}
