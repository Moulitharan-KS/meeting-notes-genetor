package com.meetingnotes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a speaker in a meeting.
 *
 * The tone / toneNote fields power the "Speaker Analysis" extended
 * feature: a one-word contribution style (e.g. Decisive, Inquisitive)
 * derived from what the speaker actually said, plus a short rationale.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Speaker {
    private String id;
    private String name;
    private int speakingTime; // seconds
    private int wordCount;
    private String tone;
    private String toneNote;
}
