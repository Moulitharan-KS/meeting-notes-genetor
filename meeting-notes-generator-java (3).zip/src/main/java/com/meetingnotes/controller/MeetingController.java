package com.meetingnotes.controller;

import com.meetingnotes.model.ActionItem;
import com.meetingnotes.model.MeetingResult;
import com.meetingnotes.service.ExportService;
import com.meetingnotes.service.MeetingProcessorService;
import com.meetingnotes.service.MeetingSessionStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * Web + REST controller for the Meeting Notes Generator.
 *
 * "/" renders the Thymeleaf page (mirrors app.py's main interface).
 * "/api/process" handles upload and runs the full pipeline (mirrors
 * _process_uploaded_file). "/api/tasks/{id}/status" and the export
 * endpoints back the two extended features: the kanban status board
 * and the .ics / Markdown export.
 */
@Controller
public class MeetingController {

    private final MeetingProcessorService processorService;
    private final MeetingSessionStore sessionStore;
    private final ExportService exportService;

    @Value("${app.assemblyai.api-key:}")
    private String defaultAssemblyAiKey;

    @Value("${app.openai.api-key:}")
    private String defaultOpenAiKey;

    public MeetingController(MeetingProcessorService processorService,
                              MeetingSessionStore sessionStore,
                              ExportService exportService) {
        this.processorService = processorService;
        this.sessionStore = sessionStore;
        this.exportService = exportService;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("result", sessionStore.getCurrentResult());
        model.addAttribute("taskStatus", sessionStore.getTaskStatusMap());
        model.addAttribute("hasDefaultKeys",
                !defaultAssemblyAiKey.isBlank() && !defaultOpenAiKey.isBlank());
        return "index";
    }

    @PostMapping("/api/process")
    @ResponseBody
    public ResponseEntity<?> processAudio(
            @RequestParam("audio") MultipartFile audioFile,
            @RequestParam(value = "assemblyAiKey", required = false) String assemblyAiKey,
            @RequestParam(value = "openAiKey", required = false) String openAiKey
    ) {
        String resolvedAssemblyKey = blankToDefault(assemblyAiKey, defaultAssemblyAiKey);
        String resolvedOpenAiKey = blankToDefault(openAiKey, defaultOpenAiKey);

        if (!isValidKey(resolvedAssemblyKey) || !isValidKey(resolvedOpenAiKey)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "error", "Please provide valid AssemblyAI and OpenAI API keys (or configure defaults in application.properties)."
            ));
        }

        File tempFile = null;
        try {
            String originalName = audioFile.getOriginalFilename() == null ? "audio" : audioFile.getOriginalFilename();
            String suffix = originalName.contains(".") ? originalName.substring(originalName.lastIndexOf('.')) : ".tmp";
            tempFile = File.createTempFile("meeting-audio-", suffix);
            audioFile.transferTo(tempFile);

            MeetingResult result = processorService.processMeetingAudio(tempFile, resolvedAssemblyKey, resolvedOpenAiKey);
            sessionStore.setCurrentResult(result);

            return ResponseEntity.ok(Map.of("status", "ok", "title", result.getTitle()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Processing failed: " + e.getMessage()));
        } finally {
            if (tempFile != null && tempFile.exists()) {
                tempFile.delete();
            }
        }
    }

    @PostMapping("/api/tasks/{taskId}/status")
    @ResponseBody
    public ResponseEntity<?> updateTaskStatus(@PathVariable String taskId, @RequestBody Map<String, String> body) {
        String status = body.get("status");
        if (status == null || !List.of("Not started", "In progress", "Done").contains(status)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid status"));
        }
        sessionStore.updateTaskStatus(taskId, status);
        return ResponseEntity.ok(Map.of("status", "updated"));
    }

    @PostMapping("/api/reset")
    @ResponseBody
    public ResponseEntity<?> reset() {
        sessionStore.clear();
        return ResponseEntity.ok(Map.of("status", "cleared"));
    }

    @GetMapping("/api/export/ics")
    public ResponseEntity<byte[]> exportIcs() {
        MeetingResult result = sessionStore.getCurrentResult();
        if (result == null) {
            return ResponseEntity.notFound().build();
        }
        List<ActionItem> itemsWithDates = result.getActionItems().stream()
                .filter(i -> i.getDueDate() != null && !i.getDueDate().isBlank())
                .toList();

        String ics = exportService.buildIcs(itemsWithDates);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=meeting_action_items.ics")
                .contentType(MediaType.parseMediaType("text/calendar"))
                .body(ics.getBytes());
    }

    @GetMapping("/api/export/markdown")
    public ResponseEntity<byte[]> exportMarkdown() {
        MeetingResult result = sessionStore.getCurrentResult();
        if (result == null) {
            return ResponseEntity.notFound().build();
        }
        String md = exportService.generateMarkdownExport(result, sessionStore.getTaskStatusMap());
        String filename = "meeting_notes_" + result.getProcessedAt().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm")) + ".md";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("text/markdown"))
                .body(md.getBytes());
    }

    private String blankToDefault(String provided, String fallback) {
        return (provided == null || provided.isBlank()) ? fallback : provided;
    }

    private boolean isValidKey(String key) {
        return key != null && key.length() >= 20;
    }
}
