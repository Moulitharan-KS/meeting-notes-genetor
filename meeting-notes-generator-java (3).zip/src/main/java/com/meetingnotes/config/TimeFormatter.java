package com.meetingnotes.config;

import org.springframework.stereotype.Component;

/** Formats a millisecond timestamp as mm:ss, used throughout the transcript and speaker statement views. */
@Component("timeFormatter")
public class TimeFormatter {

    public String mmss(long milliseconds) {
        long totalSeconds = milliseconds / 1000;
        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
}
