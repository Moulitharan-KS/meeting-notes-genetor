package com.meetingnotes.config;

import com.meetingnotes.model.ActionItem;
import com.meetingnotes.model.Speaker;
import org.springframework.stereotype.Component;

import java.util.List;

/** Small calculations used by the Thymeleaf template that don't belong on the model itself. */
@Component("speakerStats")
public class SpeakerStats {

    public int percentOf(Speaker speaker, List<Speaker> allSpeakers) {
        int total = allSpeakers.stream().mapToInt(Speaker::getSpeakingTime).sum();
        if (total == 0) return 0;
        return Math.round(100f * speaker.getSpeakingTime() / total);
    }

    public boolean anyDueDates(List<ActionItem> items) {
        return items.stream().anyMatch(i -> i.getDueDate() != null && !i.getDueDate().isBlank());
    }
}
