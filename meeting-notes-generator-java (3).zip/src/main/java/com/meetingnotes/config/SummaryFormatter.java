package com.meetingnotes.config;

import org.springframework.stereotype.Component;

import java.util.regex.Pattern;

/**
 * Converts the bullet/heading-style summary text (as produced by
 * TextAnalyzerService.generateMeetingSummary) into safe HTML for display,
 * mirroring display_meeting_summary() from the original Streamlit app.
 */
@Component("summaryFormatter")
public class SummaryFormatter {

    private static final String[] HEADINGS = {"Topics Discussed", "Key Decisions", "Next Steps"};

    public String format(String summary) {
        if (summary == null) return "";

        StringBuilder html = new StringBuilder();
        boolean inList = false;

        // Apply heading replacement first, on the raw (unescaped) text,
        // then escape remaining content line by line so user-supplied
        // transcript text can never inject markup.
        String withHeadings = summary;
        for (String heading : HEADINGS) {
            String pattern = Pattern.quote("**" + heading + ":**");
            withHeadings = withHeadings.replaceAll(pattern, "\u0001" + heading + "\u0001");
        }

        for (String rawLine : withHeadings.split("\n")) {
            String trimmed = rawLine.trim();

            if (trimmed.startsWith("\u0001") && trimmed.endsWith("\u0001")) {
                String heading = trimmed.substring(1, trimmed.length() - 1);
                if (inList) {
                    html.append("</ul>");
                    inList = false;
                }
                html.append("<div class=\"eyebrow\" style=\"margin-top:18px;\">")
                        .append(escapeHtml(heading)).append("</div>");
                continue;
            }

            if (trimmed.startsWith("\u2022 ")) {
                if (!inList) {
                    html.append("<ul style=\"margin:6px 0 14px 0; padding-left:20px;\">");
                    inList = true;
                }
                String content = trimmed.substring(2).trim();
                html.append("<li style=\"margin:5px 0; line-height:1.55;\">")
                        .append(escapeHtml(content)).append("</li>");
            } else {
                if (inList) {
                    html.append("</ul>");
                    inList = false;
                }
                if (!trimmed.isEmpty()) {
                    html.append(escapeHtml(trimmed)).append(" ");
                }
            }
        }
        if (inList) html.append("</ul>");

        return html.toString();
    }

    private String escapeHtml(String text) {
        return text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;");
    }
}
