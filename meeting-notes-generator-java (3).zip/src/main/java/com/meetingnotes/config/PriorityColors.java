package com.meetingnotes.config;

import org.springframework.stereotype.Component;

import java.util.Map;

/** Maps an action item priority (high/medium/low) to its display color pair, ported from theme.py's PRIORITY_COLORS. */
@Component("priorityColors")
public class PriorityColors {

    private record ColorPair(String color, String soft) {}

    private static final Map<String, ColorPair> COLORS = Map.of(
            "high", new ColorPair("#DC2626", "#FDECEC"),
            "medium", new ColorPair("#D97706", "#FEF6E8"),
            "low", new ColorPair("#16A34A", "#EFF9F0")
    );

    public String colorFor(String priority) {
        String key = priority == null ? "medium" : priority.toLowerCase();
        return COLORS.getOrDefault(key, COLORS.get("medium")).color();
    }

    public String softFor(String priority) {
        String key = priority == null ? "medium" : priority.toLowerCase();
        return COLORS.getOrDefault(key, COLORS.get("medium")).soft();
    }
}
