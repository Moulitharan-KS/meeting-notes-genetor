package com.meetingnotes.config;

import org.springframework.stereotype.Component;

import java.util.Map;

/** Maps a speaker's tone label (Decisive, Inquisitive, ...) to a display color, ported from theme.py's _TONE_COLORS. */
@Component("toneColors")
public class ToneColors {

    private static final Map<String, String> COLORS = Map.of(
            "Decisive", "#2D5BFF",
            "Inquisitive", "#7C3AED",
            "Supportive", "#16A34A",
            "Analytical", "#0891B2",
            "Persuasive", "#D97706",
            "Reserved", "#6B7280"
    );

    private static final String DEFAULT = "#2D5BFF";

    public String colorFor(String tone) {
        return COLORS.getOrDefault(tone, DEFAULT);
    }

    public String softFor(String tone) {
        return colorFor(tone) + "1A"; // ~10% alpha, matching the Python f"{color}1A" pattern
    }
}
