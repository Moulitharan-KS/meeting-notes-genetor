/* Meeting Notes Generator — client-side interactivity.
   Replaces Streamlit's reactive reruns with plain fetch() calls. */

document.addEventListener("DOMContentLoaded", () => {
    const fileInput = document.getElementById("audio-file");
    const fileDrop = document.getElementById("file-drop");
    const processBtn = document.getElementById("process-btn");
    const resetBtn = document.getElementById("reset-btn");
    const statusBanner = document.getElementById("status-banner");

    if (fileInput && fileDrop) {
        fileInput.addEventListener("change", () => {
            if (fileInput.files.length > 0) {
                fileDrop.textContent = `Selected: ${fileInput.files[0].name}`;
                fileDrop.classList.add("has-file");
                if (processBtn) processBtn.disabled = false;
            }
        });
    }

    if (processBtn) {
        processBtn.addEventListener("click", async () => {
            if (!fileInput || fileInput.files.length === 0) return;

            const assemblyKey = document.getElementById("assemblyai-key")?.value || "";
            const openaiKey = document.getElementById("openai-key")?.value || "";

            const formData = new FormData();
            formData.append("audio", fileInput.files[0]);
            if (assemblyKey) formData.append("assemblyAiKey", assemblyKey);
            if (openaiKey) formData.append("openAiKey", openaiKey);

            processBtn.disabled = true;
            processBtn.textContent = "Processing\u2026";
            setBanner("info", "\uD83D\uDD04 Processing audio\u2026 this can take a minute or two.");

            try {
                const res = await fetch("/api/process", { method: "POST", body: formData });
                const data = await res.json();

                if (!res.ok) {
                    setBanner("error", "\u274C " + (data.error || "Processing failed."));
                    processBtn.disabled = false;
                    processBtn.textContent = "\uD83D\uDE80 Start Processing";
                    return;
                }

                setBanner("success", "\u2705 Processing complete! Reloading results\u2026");
                window.location.reload();
            } catch (err) {
                setBanner("error", "\u274C Processing failed: " + err.message);
                processBtn.disabled = false;
                processBtn.textContent = "\uD83D\uDE80 Start Processing";
            }
        });
    }

    if (resetBtn) {
        resetBtn.addEventListener("click", async () => {
            await fetch("/api/reset", { method: "POST" });
            window.location.reload();
        });
    }

    // Kanban status dropdowns
    document.querySelectorAll(".task-status-select").forEach((select) => {
        select.addEventListener("change", async (e) => {
            const taskId = e.target.dataset.taskId;
            const status = e.target.value;
            await fetch(`/api/tasks/${encodeURIComponent(taskId)}/status`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ status }),
            });
            window.location.reload();
        });
    });

    function setBanner(type, text) {
        if (!statusBanner) return;
        statusBanner.className = "alert alert-" + type;
        statusBanner.textContent = text;
        statusBanner.style.display = "block";
    }
});
