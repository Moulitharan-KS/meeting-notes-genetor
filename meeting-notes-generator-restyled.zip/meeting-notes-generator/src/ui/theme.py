"""Shared design tokens and global CSS for the Meeting Notes Generator.

Every screen pulls from this single module so the look stays uniform
across the sidebar, header, summary, speaker analysis, action board,
and transcript.
"""

import streamlit as st

# ---------------------------------------------------------------------------
# Design tokens
# ---------------------------------------------------------------------------

INK = "#1A1D29"            # primary text
INK_SOFT = "#6B7280"       # secondary text
PAPER = "#FAFAF8"          # page background (warm white)
CARD = "#FFFFFF"           # card background
BORDER = "#E7E5E0"         # hairline border
ACCENT = "#2D5BFF"         # primary accent (indigo-blue)
ACCENT_SOFT = "#EEF1FF"    # tinted accent background
ACCENT_DARK = "#1E40D6"    # hover / pressed state

SUCCESS = "#16A34A"
SUCCESS_SOFT = "#EFF9F0"
WARNING = "#D97706"
WARNING_SOFT = "#FEF6E8"
DANGER = "#DC2626"
DANGER_SOFT = "#FDECEC"
NEUTRAL_SOFT = "#F1F0EC"

RADIUS = "12px"
RADIUS_SM = "8px"

PRIORITY_COLORS = {
    "high": (DANGER, DANGER_SOFT),
    "medium": (WARNING, WARNING_SOFT),
    "low": (SUCCESS, SUCCESS_SOFT),
}

STATUS_COLORS = {
    "Not started": (INK_SOFT, NEUTRAL_SOFT),
    "In progress": (ACCENT, ACCENT_SOFT),
    "Done": (SUCCESS, SUCCESS_SOFT),
}


def inject_global_styles() -> None:
    """Inject the global stylesheet. Call once near the top of the app."""
    st.markdown(
        f"""
        <style>
            /* ---------- page shell ---------- */
            .stApp {{
                background: {PAPER};
            }}
            .block-container {{
                padding-top: 2rem;
                max-width: 1100px;
            }}
            html, body, [class*="css"] {{
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI",
                             Inter, Roboto, sans-serif;
                color: {INK};
            }}

            /* ---------- sidebar ---------- */
            section[data-testid="stSidebar"] {{
                background: {CARD};
                border-right: 1px solid {BORDER};
            }}
            section[data-testid="stSidebar"] .block-container {{
                padding-top: 1.5rem;
            }}

            /* ---------- typography ---------- */
            .mn-eyebrow {{
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 0.06em;
                text-transform: uppercase;
                color: {INK_SOFT};
                margin-bottom: 4px;
            }}
            .mn-section-title {{
                font-size: 22px;
                font-weight: 700;
                color: {INK};
                margin: 0 0 14px 0;
                display: flex;
                align-items: center;
                gap: 10px;
            }}
            .mn-subtitle {{
                font-size: 14px;
                color: {INK_SOFT};
                margin-top: -8px;
                margin-bottom: 18px;
            }}

            /* ---------- cards ---------- */
            .mn-card {{
                background: {CARD};
                border: 1px solid {BORDER};
                border-radius: {RADIUS};
                padding: 22px 24px;
                margin-bottom: 18px;
                box-shadow: 0 1px 2px rgba(20, 20, 15, 0.03);
            }}
            .mn-card + .mn-card {{
                margin-top: 0;
            }}

            /* ---------- ledger rows (left accent bar list items) ------- */
            .mn-ledger-item {{
                border-left: 3px solid {ACCENT};
                background: {ACCENT_SOFT};
                border-radius: 0 {RADIUS_SM} {RADIUS_SM} 0;
                padding: 12px 16px;
                margin-bottom: 10px;
            }}
            .mn-ledger-item.neutral {{
                border-left-color: {BORDER};
                background: {NEUTRAL_SOFT};
            }}

            /* ---------- chips / badges ---------- */
            .mn-chip {{
                display: inline-flex;
                align-items: center;
                gap: 4px;
                font-size: 12px;
                font-weight: 600;
                padding: 3px 10px;
                border-radius: 999px;
                white-space: nowrap;
            }}

            /* ---------- header banner ---------- */
            .mn-hero {{
                text-align: center;
                padding: 8px 0 4px 0;
            }}
            .mn-hero h1 {{
                font-size: 30px;
                font-weight: 700;
                color: {INK};
                margin-bottom: 6px;
            }}
            .mn-hero .mn-powered {{
                color: {INK_SOFT};
                font-size: 13px;
            }}

            /* ---------- buttons (Streamlit overrides) ---------- */
            .stButton > button, .stDownloadButton > button {{
                background: {ACCENT};
                color: #FFFFFF;
                border: none;
                border-radius: {RADIUS_SM};
                font-weight: 600;
                padding: 0.5rem 1.1rem;
                transition: background 0.15s ease;
            }}
            .stButton > button:hover, .stDownloadButton > button:hover {{
                background: {ACCENT_DARK};
                color: #FFFFFF;
            }}
            .stButton > button[kind="secondary"] {{
                background: {CARD};
                color: {INK};
                border: 1px solid {BORDER};
            }}
            .stButton > button[kind="secondary"]:hover {{
                background: {NEUTRAL_SOFT};
                color: {INK};
            }}

            /* ---------- metrics ---------- */
            div[data-testid="stMetric"] {{
                background: {CARD};
                border: 1px solid {BORDER};
                border-radius: {RADIUS_SM};
                padding: 14px 16px 10px 16px;
            }}
            div[data-testid="stMetricValue"] {{
                color: {INK};
            }}
            div[data-testid="stMetricLabel"] {{
                color: {INK_SOFT};
            }}

            /* ---------- expander ---------- */
            details {{
                border: 1px solid {BORDER} !important;
                border-radius: {RADIUS_SM} !important;
                background: {CARD};
            }}

            /* ---------- text input / file uploader ---------- */
            .stTextInput > div > div, .stFileUploader > div {{
                border-radius: {RADIUS_SM};
            }}
            section[data-testid="stFileUploaderDropzone"] {{
                background: {NEUTRAL_SOFT};
                border: 1.5px dashed {BORDER};
                border-radius: {RADIUS_SM};
            }}

            /* ---------- divider ---------- */
            hr {{
                border-color: {BORDER};
            }}

            /* ---------- transcript box ---------- */
            .mn-transcript-box {{
                background: {NEUTRAL_SOFT};
                border: 1px solid {BORDER};
                border-radius: {RADIUS_SM};
                padding: 16px 18px;
                max-height: 420px;
                overflow-y: auto;
            }}
            .mn-transcript-line {{
                font-size: 14px;
                line-height: 1.7;
                color: {INK};
                margin-bottom: 10px;
            }}
            .mn-transcript-speaker {{
                color: {ACCENT_DARK};
                font-weight: 700;
            }}
            .mn-transcript-meta {{
                color: {INK_SOFT};
                font-weight: 400;
            }}

            /* ---------- speaker bar chart ---------- */
            .mn-bar-row {{
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 10px;
            }}
            .mn-bar-label {{
                width: 130px;
                font-size: 13px;
                font-weight: 600;
                color: {INK};
                flex-shrink: 0;
            }}
            .mn-bar-track {{
                flex: 1;
                height: 10px;
                background: {NEUTRAL_SOFT};
                border-radius: 999px;
                overflow: hidden;
            }}
            .mn-bar-fill {{
                height: 100%;
                background: {ACCENT};
                border-radius: 999px;
            }}
            .mn-bar-value {{
                width: 64px;
                text-align: right;
                font-size: 12px;
                color: {INK_SOFT};
                flex-shrink: 0;
            }}

            /* ---------- kanban board ---------- */
            .mn-kanban-col-title {{
                font-size: 13px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 0.04em;
                margin-bottom: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }}
            .mn-task-card {{
                background: {CARD};
                border: 1px solid {BORDER};
                border-radius: {RADIUS_SM};
                padding: 12px 14px;
                margin-bottom: 10px;
            }}
            .mn-task-desc {{
                font-size: 14px;
                color: {INK};
                line-height: 1.5;
                margin-bottom: 8px;
            }}
            .mn-task-meta-row {{
                display: flex;
                gap: 6px;
                flex-wrap: wrap;
            }}

            /* ---------- alert boxes ---------- */
            div[data-testid="stAlertContentSuccess"] {{
                color: {SUCCESS};
            }}
            div[data-testid="stAlertContentInfo"] {{
                color: {ACCENT_DARK};
            }}
            div[data-testid="stAlertContentWarning"] {{
                color: {WARNING};
            }}
            div[data-testid="stAlertContentError"] {{
                color: {DANGER};
            }}
            .stAlert {{
                border-radius: {RADIUS_SM};
                border: 1px solid {BORDER};
            }}

            /* ---------- empty state ---------- */
            .mn-empty {{
                text-align: center;
                padding: 36px 20px;
                color: {INK_SOFT};
            }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def section_title(icon: str, text: str) -> str:
    """Return HTML for a uniform section title used on every screen."""
    return f'<div class="mn-section-title">{icon} {text}</div>'


def chip_html(label: str, color: str, soft_bg: str) -> str:
    return (
        f'<span class="mn-chip" style="color:{color}; background:{soft_bg};">'
        f"{label}</span>"
    )
