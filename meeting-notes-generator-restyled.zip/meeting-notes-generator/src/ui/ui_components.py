"""UI components for displaying meeting results.

All visual styling is driven by src.ui.theme so every screen (summary,
speaker analysis, action items, transcript) stays uniform.
"""

import uuid
import re
from datetime import datetime, timedelta
from typing import List, Optional

import streamlit as st

from src.data.data_models import MeetingResult, Speaker, ActionItem
from src.ui.theme import (
    INK,
    INK_SOFT,
    ACCENT,
    ACCENT_SOFT,
    ACCENT_DARK,
    BORDER,
    NEUTRAL_SOFT,
    PRIORITY_COLORS,
    STATUS_COLORS,
    section_title,
    chip_html,
)


# ---------------------------------------------------------------------------
# Header / metrics
# ---------------------------------------------------------------------------

def display_meeting_header(result: MeetingResult) -> None:
    """Display the main meeting header with key metrics."""
    st.markdown(
        f'<div class="mn-eyebrow">{result.processed_at.strftime("%B %d, %Y · %I:%M %p")}</div>'
        f'<h2 style="margin-top:0; margin-bottom:18px; color:{INK};">{result.title}</h2>',
        unsafe_allow_html=True,
    )

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Duration", f"{result.duration // 60}m {result.duration % 60}s")
    with col2:
        st.metric("Speakers", len(result.speakers))
    with col3:
        st.metric("Action items", len(result.action_items))
    with col4:
        st.metric("Language", result.language.upper())


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def display_meeting_summary(summary: str) -> None:
    """Display the generated meeting summary with clear, uniform formatting."""
    st.markdown(section_title("📝", "Meeting summary"), unsafe_allow_html=True)

    essential_headings = ["Topics Discussed", "Key Decisions", "Next Steps"]

    enhanced_summary = summary
    for heading in essential_headings:
        enhanced_summary = re.sub(
            rf"\*\*{re.escape(heading)}:\*\*",
            f'<div class="mn-eyebrow" style="margin-top:18px;">{heading}</div>',
            enhanced_summary,
        )

    sections = enhanced_summary.split("\n\n")
    processed_sections = []

    for section in sections:
        if not section.strip():
            continue
        lines = section.split("\n")
        processed_lines = []
        in_list = False

        for line in lines:
            line = line.strip()
            if line.startswith("• "):
                if not in_list:
                    processed_lines.append('<ul style="margin: 6px 0 14px 0; padding-left: 20px;">')
                    in_list = True
                content = line[2:].strip()
                processed_lines.append(
                    f'<li style="margin: 5px 0; color:{INK}; line-height:1.55;">{content}</li>'
                )
            else:
                if in_list:
                    processed_lines.append("</ul>")
                    in_list = False
                if line:
                    processed_lines.append(line)

        if in_list:
            processed_lines.append("</ul>")

        processed_sections.append("\n".join(processed_lines))

    final_summary = "\n".join(processed_sections)

    st.markdown(
        f'<div class="mn-card"><div style="font-size:15px; line-height:1.5; color:{INK};">'
        f"{final_summary}</div></div>",
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Speaker analysis (extended feature #1)
# ---------------------------------------------------------------------------

_TONE_COLORS = {
    "Decisive": "#2D5BFF",
    "Inquisitive": "#7C3AED",
    "Supportive": "#16A34A",
    "Analytical": "#0891B2",
    "Persuasive": "#D97706",
    "Reserved": "#6B7280",
}


def _tone_chip(tone: Optional[str]) -> str:
    if not tone:
        return ""
    color = _TONE_COLORS.get(tone, ACCENT)
    return chip_html(tone, color, f"{color}1A")


def display_speaker_analysis(speakers: List[Speaker], segments) -> None:
    """Display speaker breakdown: speaking-time chart, tone tags, and statements.

    Extended beyond the original plain-text list with:
    - a proportional speaking-time bar chart so contribution is visible at a glance
    - a tone tag per speaker (Decisive / Inquisitive / Supportive / ...) generated
      from what they actually said, with a one-line rationale
    """
    st.markdown(section_title("👥", "Speaker analysis"), unsafe_allow_html=True)

    if not speakers:
        st.markdown(
            '<div class="mn-card mn-empty">No speaker information available.</div>',
            unsafe_allow_html=True,
        )
        return

    total_time = sum(s.speaking_time for s in speakers) or 1

    st.markdown('<div class="mn-card">', unsafe_allow_html=True)
    st.markdown('<div class="mn-eyebrow">Speaking time share</div>', unsafe_allow_html=True)
    bars_html = ""
    for speaker in sorted(speakers, key=lambda s: -s.speaking_time):
        pct = round(100 * speaker.speaking_time / total_time)
        mins = f"{speaker.speaking_time // 60}m {speaker.speaking_time % 60}s"
        bars_html += f"""
        <div class="mn-bar-row">
            <div class="mn-bar-label">{speaker.name}</div>
            <div class="mn-bar-track">
                <div class="mn-bar-fill" style="width:{pct}%;"></div>
            </div>
            <div class="mn-bar-value">{pct}% · {mins}</div>
        </div>
        """
    st.markdown(bars_html, unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

    for speaker in speakers:
        speaking_time = f"{speaker.speaking_time // 60}m {speaker.speaking_time % 60}s"
        tone_chip = _tone_chip(speaker.tone)
        tone_note_html = (
            f'<div style="color:{INK_SOFT}; font-size:13px; margin-top:8px; font-style:italic;">"{speaker.tone_note}"</div>'
            if speaker.tone_note
            else ""
        )

        st.markdown(
            f"""
            <div class="mn-card" style="margin-bottom:14px;">
                <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:8px;">
                    <div style="font-size:16px; font-weight:700; color:{INK};">{speaker.name}</div>
                    {tone_chip}
                </div>
                <div style="color:{INK_SOFT}; font-size:13px; margin-top:4px;">
                    {speaking_time} spoken · {speaker.word_count} words
                </div>
                {tone_note_html}
            </div>
            """,
            unsafe_allow_html=True,
        )

        speaker_segments = [seg for seg in segments if seg.speaker_id == speaker.id]
        if speaker_segments:
            with st.expander(f"View all statements from {speaker.name}", expanded=False):
                for i, segment in enumerate(speaker_segments, 1):
                    timestamp = f"{segment.start_time // 60000:02d}:{segment.start_time // 1000 % 60:02d}"
                    low_conf = (
                        f'<span style="color:{INK_SOFT}; font-size:12px;"> · low confidence ({segment.confidence:.2f})</span>'
                        if segment.confidence < 0.7
                        else ""
                    )
                    st.markdown(
                        f"""
                        <div style="margin-bottom:10px; padding-bottom:10px; border-bottom:1px solid {BORDER};">
                            <div style="font-size:12px; color:{INK_SOFT};">Statement {i} · {timestamp}{low_conf}</div>
                            <div style="font-size:14px; color:{INK}; margin-top:2px;">{segment.text}</div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
        else:
            st.caption("No statements found.")


# ---------------------------------------------------------------------------
# Action items (extended feature #2)
# ---------------------------------------------------------------------------

def _ensure_status_state(action_items: List[ActionItem]) -> None:
    """Make sure each action item has a tracked status in session state."""
    if "task_status" not in st.session_state:
        st.session_state.task_status = {}
    for item in action_items:
        key = item.id or item.description
        if key not in st.session_state.task_status:
            st.session_state.task_status[key] = item.status or "Not started"


def _task_card_html(item: ActionItem) -> str:
    priority = (item.priority or "medium").lower()
    p_color, p_soft = PRIORITY_COLORS.get(priority, PRIORITY_COLORS["medium"])

    chips = chip_html(priority.title(), p_color, p_soft)
    if item.due_date:
        chips += " " + chip_html(f"Due {item.due_date}", INK_SOFT, NEUTRAL_SOFT)
    if item.assignee:
        chips += " " + chip_html(item.assignee, ACCENT_DARK, ACCENT_SOFT)

    return f"""
    <div class="mn-task-card">
        <div class="mn-task-desc">{item.description}</div>
        <div class="mn-task-meta-row">{chips}</div>
    </div>
    """


def display_action_items(action_items: List[ActionItem]) -> None:
    """Display action items as an interactive status board (kanban-style).

    Extended beyond the original static, assignee-grouped list with:
    - a tracked status per task (Not started / In progress / Done) the user
      can change interactively, persisted in session state
    - a kanban-style board grouped by status instead of a flat list
    - a downloadable .ics calendar file for every item that has a due date
    """
    st.markdown(section_title("✅", "Action items"), unsafe_allow_html=True)

    if not action_items:
        st.markdown(
            '<div class="mn-card mn-empty">No action items were identified in this meeting.</div>',
            unsafe_allow_html=True,
        )
        return

    _ensure_status_state(action_items)

    st.markdown('<div class="mn-card">', unsafe_allow_html=True)
    st.markdown('<div class="mn-eyebrow">Update task status</div>', unsafe_allow_html=True)
    for item in action_items:
        key = item.id or item.description
        cols = st.columns([5, 2])
        with cols[0]:
            st.markdown(
                f'<div style="font-size:14px; color:{INK}; padding-top:6px;">{item.description}</div>',
                unsafe_allow_html=True,
            )
        with cols[1]:
            current = st.session_state.task_status.get(key, "Not started")
            options = ["Not started", "In progress", "Done"]
            new_status = st.selectbox(
                "Status",
                options,
                index=options.index(current) if current in options else 0,
                key=f"status_select_{key}",
                label_visibility="collapsed",
            )
            st.session_state.task_status[key] = new_status
    st.markdown("</div>", unsafe_allow_html=True)

    columns_meta = [
        ("Not started", "📋"),
        ("In progress", "🔄"),
        ("Done", "✅"),
    ]
    board_cols = st.columns(3)

    for (status_name, icon), col in zip(columns_meta, board_cols):
        with col:
            color, _ = STATUS_COLORS.get(status_name, (INK_SOFT, NEUTRAL_SOFT))
            items_here = [
                item
                for item in action_items
                if st.session_state.task_status.get(item.id or item.description, "Not started") == status_name
            ]
            st.markdown(
                f'<div class="mn-kanban-col-title" style="color:{color};">{icon} {status_name} ({len(items_here)})</div>',
                unsafe_allow_html=True,
            )
            if items_here:
                for item in items_here:
                    st.markdown(_task_card_html(item), unsafe_allow_html=True)
            else:
                st.markdown(
                    f'<div style="color:{INK_SOFT}; font-size:13px; padding:8px 0;">Nothing here</div>',
                    unsafe_allow_html=True,
                )

    items_with_dates = [item for item in action_items if item.due_date]
    if items_with_dates:
        st.markdown("<div style='height:6px;'></div>", unsafe_allow_html=True)
        ics_content = _build_ics(items_with_dates)
        st.download_button(
            label=f"📅 Add {len(items_with_dates)} due date(s) to calendar (.ics)",
            data=ics_content,
            file_name="meeting_action_items.ics",
            mime="text/calendar",
        )


def _parse_due_date(due_date: str) -> Optional[datetime]:
    """Best-effort parse of a free-text due date into a datetime.

    The model returns due dates as natural language (e.g. "Friday",
    "next week", "2024-03-15"). Only common, unambiguous formats are
    attempted; anything else is skipped rather than guessed incorrectly.
    """
    due_date = due_date.strip()
    formats = ["%Y-%m-%d", "%m/%d/%Y", "%B %d, %Y", "%B %d", "%b %d, %Y", "%b %d"]
    for fmt in formats:
        try:
            parsed = datetime.strptime(due_date, fmt)
            if parsed.year == 1900:
                parsed = parsed.replace(year=datetime.now().year)
            return parsed
        except ValueError:
            continue
    return None


def _build_ics(items: List[ActionItem]) -> str:
    """Hand-build a minimal valid .ics calendar file (no extra dependency).

    Items whose due date can't be confidently parsed are skipped, so the
    exported calendar never contains a guessed/incorrect date.
    """
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Meeting Notes Generator//EN",
    ]

    now_stamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    included = 0

    for item in items:
        parsed = _parse_due_date(item.due_date)
        if not parsed:
            continue
        included += 1
        dt_value = parsed.strftime("%Y%m%d")
        summary = item.description.replace("\n", " ").replace(",", "\\,")
        description_parts = []
        if item.assignee:
            description_parts.append(f"Assigned to: {item.assignee}")
        if item.priority:
            description_parts.append(f"Priority: {item.priority.title()}")
        description = " | ".join(description_parts).replace(",", "\\,")

        lines.extend(
            [
                "BEGIN:VEVENT",
                f"UID:{uuid.uuid4()}",
                f"DTSTAMP:{now_stamp}",
                f"DTSTART;VALUE=DATE:{dt_value}",
                f"DTEND;VALUE=DATE:{(parsed + timedelta(days=1)).strftime('%Y%m%d')}",
                f"SUMMARY:{summary}",
                f"DESCRIPTION:{description}",
                "END:VEVENT",
            ]
        )

    lines.append("END:VCALENDAR")

    if included == 0:
        return "\n".join(["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Meeting Notes Generator//EN", "END:VCALENDAR"])

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Transcript
# ---------------------------------------------------------------------------

def display_meeting_transcript(segments, language: str = "en", result=None) -> None:
    """Display the meeting transcript with uniform formatting."""
    st.markdown(section_title("📄", "Meeting transcript"), unsafe_allow_html=True)

    if not segments:
        st.markdown(
            '<div class="mn-card mn-empty">No transcript is available for this meeting.</div>',
            unsafe_allow_html=True,
        )
        return

    col1, col2, col3 = st.columns([1, 1, 4])
    with col1:
        show_timestamps = st.checkbox("Show timestamps", value=True)
    with col2:
        show_confidence = st.checkbox("Show confidence", value=False)

    lines_html = ""
    for segment in segments:
        timestamp = f"{segment.start_time // 60000:02d}:{segment.start_time // 1000 % 60:02d}"

        meta_bits = []
        if show_timestamps:
            meta_bits.append(timestamp)
        if show_confidence:
            meta_bits.append(f"conf {segment.confidence:.2f}")
        meta = f' <span class="mn-transcript-meta">({", ".join(meta_bits)})</span>' if meta_bits else ""

        lines_html += (
            f'<div class="mn-transcript-line">'
            f'<span class="mn-transcript-speaker">{segment.speaker_id}</span>{meta}: {segment.text}'
            f"</div>"
        )

    st.markdown(f'<div class="mn-transcript-box">{lines_html}</div>', unsafe_allow_html=True)

    st.markdown("<div style='height:22px;'></div>", unsafe_allow_html=True)
    st.markdown(section_title("📊", "Transcript statistics"), unsafe_allow_html=True)

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total segments", len(segments))
    with col2:
        st.metric("Total words", result.total_words if result else sum(len(s.text.split()) for s in segments))
    with col3:
        avg_conf = result.avg_confidence if result else (
            sum(s.confidence for s in segments) / len(segments) if segments else 0
        )
        st.metric("Avg confidence", f"{avg_conf:.2f}")
    with col4:
        unique_speakers = result.unique_speakers_count if result else len(set(s.speaker_id for s in segments))
        st.metric("Unique speakers", unique_speakers)
